export * from '@fuse/services/splash-screen/splash-screen.module';
export * from '@fuse/services/splash-screen/splash-screen.service';
